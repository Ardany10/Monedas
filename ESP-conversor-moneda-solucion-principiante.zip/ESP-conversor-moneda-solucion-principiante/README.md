#  Challenge ONE | Java | Back End | Conversor de Moneda

<p align="center" >
     <img width="500" heigth="300" src="https://user-images.githubusercontent.com/91544872/163816727-d48d3cdc-1cd8-445a-8b1c-90ed35431805.png">
</p>

### ¡Bienvenido al proyecto con la solución al desafío Conversor de Moneda con Java! Pasos principales:

#### Marca este proyecto con una estrella ⭐
#### Sigue las lecciones y las instrucciones de contenido 📚
#### Visita la página del Desafío [¡Haciendo clic aquí!](https://www.aluracursos.com/challenges/oracle-one-back-end/conversordemoneda) 📃

## Contenido de este repositório
---

Aqui encontrarás el código con la resolución al desafío del conversor de monedas, recuerda que no existe una única solución, para el mismo problema podemos encontrar diferentes tipos de soluciones y es eso lo que queremos demostrar, por eso disponibilizamos una solución para personas principiantes que están aún aprendiendo a usar este nuevo lenguaje y una solución un poco mas intermediaria, que aplica más conceptos de orientación a objetos y que va un poco más allá en el uso de buenas practicas de programación.

Ahora ¿Cómo es que puedes ver en este repositório esas soluciones? 

Es muy simple, como vemos en la siguiente imagen estamos trabajando con diferentes branchs(ramas) podemos simplemente seleccionar la branch con la solución que deseamos ver. Estas ramas son una versión nueva y separada del repositorio principal. Las branch permiten trabajar en diferentes partes de un proyecto sin afectar la rama principal, son muy usadas por los desarrolladores para probar nuevas funcionalidades en una aplicación sin afectar la versión  original. En este caso, nosotros las utilizamos para mostrarte dos alternativas posibles de como resolver este desafío.

![image](https://user-images.githubusercontent.com/91544872/185704377-e456d630-4d96-4d76-8799-aa08aeb1cd8e.png)


Una vez seleccionada la branch debes seguir el siguiente paso a paso para conseguir hacer el download del código ⬇️ 


## ⬇️ Download
---

### Cómo descargar:

#### 🔹 Fork

1 - Haz el <strong>fork</strong> del proyecto. En la parte superior derecha, al hacer clic en el icono se creará un repositorio del proyecto en tu cuenta personal de GitHub. </br>

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/169404781-7df6355b-3a15-472a-8d8e-fdb84d91a7bd.png">
</p>

2 - Una vez que tengas el repositorio "forkado" en tu cuenta, comprueba si la URL de la página es la del repositorio de tu cuenta.

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/173256272-6dd3eaba-b52e-42ec-b307-17ed785f9110.png">
</p>

3 - Haz clic en la opción <strong>Code</strong>. Se mostrarán tres formas de instalar el repositorio en su máquina, y destacamos dos:

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/173166461-e62d9704-98d5-4773-a60e-57d5729575ae.png">
</p></br>

#### 🔹 Clonar o descargar el ZIP

1 - Para clonar, simplemente copia el <em>url</em> resaltado en la imagen y ubicado justo debajo del HTTPS, crea una carpeta en tu computadora, abre el <em>cmd</em> o el <em>git bash</em> dentro de esa carpeta y luego ingresa el comando <strong>git clone</strong> y con el botón derecho del mouse dentro del terminal haz click en la opcion <strong>Paste</strong> para pegar el <em>url</em> y presiona <em>Enter</em>. 

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/173256523-79d38ee2-8668-435c-b31a-ac6ba78bb813.png">
</p>

2 - La segunda opción es descargar el código en un paquete <strong>"zipado"</strong> y extraer la carpeta a tu computadora.
</br></br>

## 📝 Eclipse

### ¿Cómo importar mi proyecto a Eclipse?

1 - Una vez dentro del Editor al lado izquierdo, haz clic en el <em>Files</em> que está en el menú en la parte superior, elige la opción <em>Open Projects from File System</em>.

<p align="center" >
     <img width="400" heigth="400" src="https://user-images.githubusercontent.com/101413385/173164237-1db32d79-2b35-433f-817c-ec3fa30899fc.png">
</p>

Luego haz click en <em>Directory</em> y ubica el directorio del proyecto "clonado" o "extraído" en tu computadora. Haz click en <em>Finish</em> para completar la importación.

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/173110215-f9451a5e-a9eb-4056-aec8-6eb3e3601e53.png">
</p>

2 - La segunda forma de importar es en <em>File</em> en la opción <em>Import</em>. O a través del <strong>Project Explorer</strong> haz clic en el campo vacío con el botón derecho del mouse y elijas la opción <strong>Import</strong>.

<p align="center" >
     <img width="400" heigth="400" src="https://user-images.githubusercontent.com/101413385/173111357-2ec928ac-5a3d-4f7c-ba84-8906d84bfd08.png">
</p>

<p align="center" >
     <img width="400" heigth="400" src="https://user-images.githubusercontent.com/101413385/169431325-23a2e3cb-85a3-4298-8e60-64dfa58e2e6f.png">
</p>

Si te decides por el <strong>Import</strong>, se abrirá la ventana correspondiente. Haz clic en la opción <em>Existing Projects Into Workspace</em> y en el botón <em>Next</em>.

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/169431890-27f40955-27d8-4b4d-82df-d3507f85de6c.png">
</p>

Luego haz clic en el botón <em>Browse</em> y busca el proyecto en el directorio local.

<p align="center" >
     <img width="600" heigth="600" src="https://user-images.githubusercontent.com/101413385/169432246-a769555c-daf9-490e-a0c7-908f7e5de967.png">
</p>


## ¿Cómo incluir mi proyecto en este Challenge?
---

1) Publicar el proyecto en GitHub
2) Utiliza el tema/topic:

 - Grupo 4: **challengeoneconversorlatam4**

Ve a la pestaña "Acerca" o "About" de tu proyecto en el menú de la izquierda dentro de tu repositorio de GitHub
Incluye la etiqueta "**challengeoneconversorlatam4**"

![gif-vitrine](https://user-images.githubusercontent.com/91544872/153601047-62aee6cb-e3cf-42b3-92c3-7130c996113f.gif)


---

## ¿Cómo hago la entrega final de mi proyecto?
---

3) Coloca tus datos en el formulario de entrega con el **link del proyecto publicado con GitHub Pages**
🔹 [link del formulario](https://lp.alura.com.br/alura-latam-entrega-challenge-one-esp-back-end)

![LATAM-pag-entrega-challenge](https://user-images.githubusercontent.com/53662778/225654748-b9ee1a2c-5b9d-4723-a787-192c65f296ae.png)


4) Accede a tu correo electrónico para conseguir tu Insignia Exclusiva para este desafío 🏆
5) ¡No olvides publicar un link o un vídeo de tu proyecto en Linkedin! 🏁

     <a href="https://www.linkedin.com/company/alura-latam/mycompany/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
